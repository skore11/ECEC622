/* This example demonstrates how to use the CUBLAS library to 
 * implement single-precision AY plus Y or SAXPY. 
 *
 * Author: Naga Kandasamy
 * Date: May 9, 2020
 */

/* Includes, system */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>

/* Includes, cuda */
#include <cublas_v2.h>
#include <cuda_runtime.h>

/* Reference implementation of SAXPY. 
 *
 * SGEMM stands for Single-precision Y = AX + Y. 
 *
 * Given vectors X and Y, SAXPY performs the following operation on each element of Y:
 *
 *  Y_i = alpha * X_i + Y_i
 *
 * where alpha is a constant.
 * */
void saxpy_gold(float *X, float *Y, float alpha, int n) 
{
    int i;
    for (i = 0; i < n; i++) 
        Y[i] = alpha * X[i] + Y[i];
}

/* Main */
int main(int argc, char **argv) 
{
 
   if (argc < 3) {
       fprintf(stderr, "Usage: %s num-elements alpha\n", argv[0]);
       fprintf(stderr, "num-elements: number of vector elements\n");
       fprintf(stderr, "alpha: scalar value\n");
       exit(EXIT_FAILURE);
   }
   
   int n = atoi(argv[1]);
   float alpha = atof(argv[2]);
    
   float *h_X, *h_Y, *h_Y_ref;       /* Pointers to vectors on host */
   float *d_X, *d_Y;                 /* Pointers to vectors on device */

  
   /* Initialize CUBLAS */
   fprintf(stderr, "Running CUBLAS test of SAXPY\n");
  
   cublasHandle_t handle;
   cublasStatus_t status;
   status = cublasCreate(&handle);
   if (status != CUBLAS_STATUS_SUCCESS) {
       fprintf(stderr, "CUBLAS initialization error\n");
       exit(EXIT_FAILURE);
   }

  /* Allocate host memory for the vectors */
  fprintf(stderr, "\nAllocating vectors on host\n");
  h_X = (float *)malloc(n * sizeof(float));
  h_Y = (float *)malloc(n * sizeof(float));

  if ((h_X == NULL) || (h_Y == NULL)) {
    fprintf(stderr, "Error allocating vectors on host\n");
    exit(EXIT_FAILURE);
  }

  /* Fill vectors with test data */
  int i;
  srand(time(NULL));
  for (i = 0; i < n; i++) {
    h_X[i] = rand() / (float)RAND_MAX;
    h_Y[i] = rand() / (float)RAND_MAX;
  }

  /* Allocate device memory for the matrices */
  if (cudaMalloc((void **)&d_X, n * sizeof(float)) != cudaSuccess) {
    fprintf(stderr, "Error allocating device memory\n");
    exit(EXIT_FAILURE);
  }
  
  if (cudaMalloc((void **)&d_Y, n * sizeof(float)) != cudaSuccess) {
    fprintf(stderr, "Error allocating device memory\n");
    exit(EXIT_FAILURE);
  }
  
  /* Initialize device vectors with the host vectors */
  status = cublasSetVector(n, sizeof(float), h_X, 1, d_X, 1);
  if (status != CUBLAS_STATUS_SUCCESS) {
    fprintf(stderr, "Error copying vector to device\n");
    exit(EXIT_FAILURE);
  }

  status = cublasSetVector(n, sizeof(float), h_Y, 1, d_Y, 1);
  if (status != CUBLAS_STATUS_SUCCESS) {
    fprintf(stderr, "Error copying vector to device\n");
    exit(EXIT_FAILURE);
  }

  /* Perform SAXPY operation using reference code */
  fprintf(stderr, "\nPerforming SAXPY operation on host\n");
  saxpy_gold(h_X, h_Y, alpha, n);
  h_Y_ref = h_Y;

  /* Perform operation using cublas */
  fprintf(stderr, "\nPerforming SAXPY operation using CUBLAS\n");
  status = cublasSaxpy(handle, n, &alpha, d_X, 1, d_Y, 1);
  if (status != CUBLAS_STATUS_SUCCESS) {
    fprintf(stderr, "Kernel execution error\n");
    exit(EXIT_FAILURE);
  }

  /* Allocate host memory for reading back the result from device memory */
  h_Y = (float *)malloc(n * sizeof(float));
  if (h_Y == NULL) {
    fprintf(stderr, "Error allocating memory on host\n");
    exit(EXIT_FAILURE);
  }

  /* Read the result back */
  status = cublasGetVector(n, sizeof(float), d_Y, 1, h_Y, 1);
  if (status != CUBLAS_STATUS_SUCCESS) {
    fprintf(stderr, "Error copying result vector to host\n");
    exit(EXIT_FAILURE);
  }

  /* Check result against reference */
  float error_norm = 0;
  float ref_norm = 0;
  float diff;
  for (i = 0; i < n; i++) {
    diff = h_Y_ref[i] - h_Y[i];
    error_norm += diff * diff;
    ref_norm += h_Y_ref[i] * h_Y_ref[i];
  }

  error_norm = sqrt(error_norm);
  ref_norm = sqrt(ref_norm);
  if (fabsf(ref_norm) < 1e-7) {
    fprintf(stderr, "Reference norm is 0\n");
    exit(EXIT_FAILURE);
  }

  /* Free memory */
  free(h_X);
  free(h_Y);
  free(h_Y_ref);

  cudaFree(d_X);
  cudaFree(d_Y);

  /* Shut down CUBLAS */
  status = cublasDestroy(handle);
  if (status != CUBLAS_STATUS_SUCCESS) {
    fprintf(stderr, "CUBLAS shutdown error\n");
    exit(EXIT_FAILURE);
  }

  if (error_norm / ref_norm < 1e-6f) {
    fprintf(stderr, "\nSGEMM test passed\n");
    exit(EXIT_SUCCESS);
  } else {
    fprintf(stderr, "\nSGEMM test failed\n");
    exit(EXIT_FAILURE);
  }
}
