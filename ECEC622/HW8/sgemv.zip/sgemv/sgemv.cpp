/* This example demonstrates how to use the CUBLAS library
 * to perform single-precision general matrix-vector multiplication.  
 *
 * Modified by: Naga Kandasamy
 * Date: May 9, 2020
 */

/* Includes, system */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>

/* Includes, cuda */
#include <cublas_v2.h>
#include <cuda_runtime.h>


/* Reference implementation of a simple version of SGEMV. 
 *
 * SGEMV stands for Single-precision GEneral Matrix-Vector Multiplication. 
 *
 * y = alpha * A * x + beta * y
 *
 * where A is a m × n matrix stored in column-major format, x and y are vectors, and alpha and beta are scalars. 
 * */
void sgemv_gold(float *A, float *X, float *Y, float alpha, float beta, int num_rows, int num_cols) 
{
    int i, j;
    float sum;
  
    for (i = 0; i < num_rows; i++) {
        sum = 0.0;
        for (j = 0; j < num_cols; j++) {
            sum += A[i + num_rows * j] * X[j]; /* Note: access is in column-major form */ 
        }
        
        Y[i] = alpha * sum + beta * Y[i];
    }   
}

int main(int argc, char **argv) 
{
    if (argc < 5) {
        fprintf(stderr, "Usage: %s num-rows num-cols alpha beta\n", argv[0]);
        fprintf(stderr, "num-rows: number of rows (height) of the matrix\n");
        fprintf(stderr, "num-cols: number of columns (width) of the matrix\n");
        fprintf(stderr, "alpha, beta: scalar values\n");
        exit(EXIT_FAILURE);
    }

    int num_rows = atoi(argv[1]);
    int num_cols = atoi(argv[2]);
    float alpha = atof(argv[3]);
    float beta = atof(argv[4]);

    float *h_A, *h_X, *h_Y, *h_Y_ref;     /* Pointers to matrices on host */
    float *d_A, *d_X, *d_Y;               /* Pointers to matrices on device */

    /* Initialize CUBLAS */
    fprintf(stderr, "Running CUBLAS test of SGEMV\n");

    cublasHandle_t handle;
    cublasStatus_t status;
    status = cublasCreate(&handle);
    if (status != CUBLAS_STATUS_SUCCESS) {
        fprintf(stderr, "CUBLAS initialization error\n");
        exit(EXIT_FAILURE);
    }

    /* Allocate host memory for the matrices */
    fprintf(stderr, "\nAllocating matrices on host\n");
    h_A = (float *)malloc(num_rows * num_cols * sizeof(float));
    h_X = (float *)malloc(num_cols * sizeof(float));
    h_Y = (float *)malloc(num_rows * sizeof(float));
    if ((h_A == NULL) || (h_X == NULL) || (h_Y == NULL)) {
        fprintf(stderr, "Error allocating matrices on host\n");
        exit(EXIT_FAILURE);
    }

    /* Fill matrices with test data */
    int i;
    srand(time(NULL));
    for (i = 0; i < num_rows * num_cols; i++) 
        h_A[i] = rand() / (float)RAND_MAX;
    
    for (i = 0; i < num_cols; i++)
        h_X[i] = rand() / (float)RAND_MAX;

    for (i = 0; i < num_rows; i++)
        h_Y[i] = rand() / (float)RAND_MAX;

    /* Allocate device memory for the matrices */
    if (cudaMalloc((void **)&d_A, num_rows * num_cols * sizeof(float)) != cudaSuccess) {
        fprintf(stderr, "Error allocating device memory\n");
        exit(EXIT_FAILURE);
    }
  
    if (cudaMalloc((void **)&d_X, num_cols * sizeof(float)) != cudaSuccess) {
        fprintf(stderr, "Error allocating device memory\n");
        exit(EXIT_FAILURE);
    }
  
    if (cudaMalloc((void **)&d_Y, num_rows * sizeof(float)) != cudaSuccess) {
        fprintf(stderr, "Error allocating device memory\n");
        exit(EXIT_FAILURE);
    }

    /* Initialize device matrices with the host matrices */
    status = cublasSetMatrix(num_rows, num_cols, sizeof(float), h_A, num_rows, d_A, num_rows);
    if (status != CUBLAS_STATUS_SUCCESS) {
        fprintf(stderr, "Error copying matrix to device\n");
        exit(EXIT_FAILURE);
    }

    status = cublasSetVector(num_cols, sizeof(float), h_X, 1, d_X, 1);
    if (status != CUBLAS_STATUS_SUCCESS) {
        fprintf(stderr, "Error copying matrix to device\n");
        exit(EXIT_FAILURE);
    }

    status = cublasSetVector(num_rows, sizeof(float), h_Y, 1, d_Y, 1);
    if (status != CUBLAS_STATUS_SUCCESS) {  
        fprintf(stderr, "Error copying matrix to device\n");    
        exit(EXIT_FAILURE);
    }

    /* Perform SGEMV operation using reference code */
    fprintf(stderr, "\nPerforming SGEMV operation on host\n");
    sgemv_gold(h_A, h_X, h_Y, alpha, beta, num_rows, num_cols);
    h_Y_ref = h_Y;

    /* Perform operation using cublas */
    fprintf(stderr, "\nPerforming SGEMV operation using CUBLAS\n");
    status = cublasSgemv(handle, CUBLAS_OP_N, num_rows, num_cols, &alpha, d_A, num_rows, d_X, 1, &beta, d_Y, 1); 
    if (status != CUBLAS_STATUS_SUCCESS) {
        fprintf(stderr, "Kernel execution error\n");
        exit(EXIT_FAILURE);
    }

    /* Allocate host memory for reading back the result from device memory */
    h_Y = (float *)malloc(num_rows * sizeof(float));
    if (h_Y == NULL) {
        fprintf(stderr, "Error allocating memory on host\n");
        exit(EXIT_FAILURE);
    }
  
    /* Read the result back */
    status = cublasGetVector(num_rows, sizeof(float), d_Y, 1, h_Y, 1);
    if (status != CUBLAS_STATUS_SUCCESS) {
        fprintf(stderr, "Error copying result matrix to host\n");
        exit(EXIT_FAILURE);
    }
  
    /* Check result against reference */
    float error_norm = 0;
    float ref_norm = 0;
    float diff;
    for (i = 0; i < num_rows; i++) {
        diff = h_Y_ref[i] - h_Y[i];
        error_norm += diff * diff;
        ref_norm += h_Y_ref[i] * h_Y_ref[i];
    }

    error_norm = sqrt(error_norm);
    ref_norm = sqrt(ref_norm);
    if (fabsf(ref_norm) < 1e-7) {
        fprintf(stderr, "Reference norm is 0\n");
        exit(EXIT_FAILURE);
    }

    /* Free memory */
    free(h_A);
    free(h_X);
    free(h_Y);
    free(h_Y_ref);

    cudaFree(d_A);
    cudaFree(d_X);
    cudaFree(d_Y);

    /* Shut down CUBLAS */
    status = cublasDestroy(handle);
    if (status != CUBLAS_STATUS_SUCCESS) {
        fprintf(stderr, "CUBLAS shutdown error\n");
        exit(EXIT_FAILURE);
    }

    if (error_norm / ref_norm < 1e-6f) {
        fprintf(stderr, "error_norm/ref_norm: %f\n", error_norm /ref_norm);
        fprintf(stderr, "\nSGEMV test passed\n");
        exit(EXIT_SUCCESS);
  
    } else {
        fprintf(stderr, "error_norm/ref_norm: %f\n", error_norm /ref_norm);
        fprintf(stderr, "\nSGEMV test failed\n");
        exit(EXIT_FAILURE);
    }
}
