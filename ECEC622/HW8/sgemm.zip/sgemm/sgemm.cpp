/*
 * Copyright 1993-2017 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/* This example demonstrates how to use the CUBLAS library
 * to perform single-precision general matrix multiplication.  
 *
 * Modified by: Naga Kandasamy
 * Date: May 9, 2020
 */

/* Includes, system */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>

/* Includes, cuda */
#include <cublas_v2.h>
#include <cuda_runtime.h>

/* Matrix size */
#define MATRIX_SIZE 256

/* Reference implementation of a simple version of SGEMM. 
 *
 * SGEMM stands for Single-precision GEneral Matrix Multiplication. 
 *
 * Given matrices A, B, and C, SGEMM performs the following operation:
 *
 * C = alpha*A*B + beta*C
 *
 * where alpha and beta are constants.
 * */
void sgemm_gold(float *A, float *B, float *C, float alpha, float beta, int n) 
{
    int i, j, k;
    float sum = 0;
  
    for (i = 0; i < n; ++i) {
        for (j = 0; j < n; ++j) {
            sum = 0;
            for (k = 0; k < n; ++k) {
                sum += A[k * n + i] * B[j * n + k];
            }

            C[j * n + i] = alpha * sum + beta * C[j * n + i];
        }
    }
}

int main(int argc, char **argv) 
{
    if (argc < 4) {
        fprintf(stderr, "Usage: %s matrix-size alpha beta\n", argv[0]);
        fprintf(stderr, "matrix-size: number of rows (columns) of the square matrix\n");
        fprintf(stderr, "alpha, beta: scalar values\n");
        exit(EXIT_FAILURE);
    }

    int matrix_size = atoi(argv[1]);
    float alpha = atof(argv[2]);
    float beta = atof(argv[3]);

  float *h_A, *h_B, *h_C, *h_C_ref; /* Pointers to matrices on host */
  float *d_A, *d_B, *d_C;           /* Pointers to matrices on device */

  /* Initialize CUBLAS */
  fprintf(stderr, "Running CUBLAS test of SGEMM\n");

  cublasHandle_t handle;
  cublasStatus_t status;
  status = cublasCreate(&handle);
  if (status != CUBLAS_STATUS_SUCCESS) {
    fprintf(stderr, "CUBLAS initialization error\n");
    exit(EXIT_FAILURE);
  }

  /* Allocate host memory for the matrices */
  fprintf(stderr, "\nAllocating matrices on host\n");
  int n = matrix_size * matrix_size;
  h_A = (float *)malloc(n * sizeof(float));
  h_B = (float *)malloc(n * sizeof(float));
  h_C = (float *)malloc(n * sizeof(float));

  if ((h_A == NULL) || (h_B == NULL) || (h_C == NULL)) {
    fprintf(stderr, "Error allocating matrices on host\n");
    exit(EXIT_FAILURE);
  }

  /* Fill matrices with test data */
  int i;
  srand(time(NULL));
  for (i = 0; i < n; i++) {
    h_A[i] = rand() / (float)RAND_MAX;
    h_B[i] = rand() / (float)RAND_MAX;
    h_C[i] = rand() / (float)RAND_MAX;
  }

  /* Allocate device memory for the matrices */
  if (cudaMalloc((void **)&d_A, n * sizeof(float)) != cudaSuccess) {
    fprintf(stderr, "Error allocating device memory\n");
    exit(EXIT_FAILURE);
  }
  
  if (cudaMalloc((void **)&d_B, n * sizeof(float)) != cudaSuccess) {
    fprintf(stderr, "Error allocating device memory\n");
    exit(EXIT_FAILURE);
  }
  
  if (cudaMalloc((void **)&d_C, n * sizeof(float)) != cudaSuccess) {
    fprintf(stderr, "Error allocating device memory\n");
    exit(EXIT_FAILURE);
  }

  /* Initialize device matrices with the host matrices */
  status = cublasSetVector(n, sizeof(float), h_A, 1, d_A, 1);
  if (status != CUBLAS_STATUS_SUCCESS) {
    fprintf(stderr, "Error copying matrix to device\n");
    exit(EXIT_FAILURE);
  }

  status = cublasSetVector(n, sizeof(float), h_B, 1, d_B, 1);
  if (status != CUBLAS_STATUS_SUCCESS) {
    fprintf(stderr, "Error copying matrix to device\n");
    exit(EXIT_FAILURE);
  }

  status = cublasSetVector(n, sizeof(float), h_C, 1, d_C, 1);
  if (status != CUBLAS_STATUS_SUCCESS) {
    fprintf(stderr, "Error copying matrix to device\n");
    exit(EXIT_FAILURE);
  }

  /* Perform SGEMM operation using reference code */
  fprintf(stderr, "\nPerforming SGEMM operation on host\n");
  sgemm_gold(h_A, h_B, h_C, alpha, beta, matrix_size);
  h_C_ref = h_C;

  /* Perform operation using cublas */
  fprintf(stderr, "\nPerforming SGEMM operation using CUBLAS\n");
  status = cublasSgemm(handle, CUBLAS_OP_N, CUBLAS_OP_N, matrix_size, matrix_size, matrix_size, 
                       &alpha, d_A, matrix_size, d_B, matrix_size, &beta, d_C, matrix_size);
  if (status != CUBLAS_STATUS_SUCCESS) {
    fprintf(stderr, "Kernel execution error\n");
    exit(EXIT_FAILURE);
  }

  /* Allocate host memory for reading back the result from device memory */
  h_C = (float *)malloc(n * sizeof(float));
  if (h_C == NULL) {
    fprintf(stderr, "Error allocating memory on host\n");
    exit(EXIT_FAILURE);
  }

  /* Read the result back */
  status = cublasGetVector(n, sizeof(float), d_C, 1, h_C, 1);
  if (status != CUBLAS_STATUS_SUCCESS) {
    fprintf(stderr, "Error copying result matrix to host\n");
    exit(EXIT_FAILURE);
  }

  /* Check result against reference */
  float error_norm = 0;
  float ref_norm = 0;
  float diff;
  for (i = 0; i < n; i++) {
    diff = h_C_ref[i] - h_C[i];
    error_norm += diff * diff;
    ref_norm += h_C_ref[i] * h_C_ref[i];
  }

  error_norm = sqrt(error_norm);
  ref_norm = sqrt(ref_norm);
  if (fabsf(ref_norm) < 1e-7) {
    fprintf(stderr, "Reference norm is 0\n");
    exit(EXIT_FAILURE);
  }

  /* Free memory */
  free(h_A);
  free(h_B);
  free(h_C);
  free(h_C_ref);

  cudaFree(d_A);
  cudaFree(d_B);
  cudaFree(d_C);

  /* Shut down CUBLAS */
  status = cublasDestroy(handle);
  if (status != CUBLAS_STATUS_SUCCESS) {
    fprintf(stderr, "CUBLAS shutdown error\n");
    exit(EXIT_FAILURE);
  }

  if (error_norm / ref_norm < 1e-6f) {
    fprintf(stderr, "\nSGEMM test passed\n");
    exit(EXIT_SUCCESS);
  } else {
    fprintf(stderr, "\nSGEMM test failed\n");
    exit(EXIT_FAILURE);
  }
}
