/* This example demonstrates how to use the CUBLAS library to 
 * implement vector dot product.
 *
 * dot = \sum_{i = 1}^n X[i] * Y[i] 
 *
 * Author: Naga Kandasamy
 * Date: May 9, 2020
 */

/* Includes, system */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>

/* Includes, cuda */
#include <cublas_v2.h>
#include <cuda_runtime.h>

/* Reference implementation of dot product. */
void dot_gold(double *X, double *Y, double *result, int n) 
{
    int i;
    double sum = 0.0;
    for (i = 0; i < n; i++) 
        sum += X[i] * Y[i];

    *result = sum;
}

int main(int argc, char **argv) 
{
 
   if (argc < 2) {
       fprintf(stderr, "Usage: %s num-elements\n", argv[0]);
       fprintf(stderr, "num-elements: number of vector elements\n");
       exit(EXIT_FAILURE);
   }
   
   int n = atoi(argv[1]);
    
   double *h_X, *h_Y;        /* Pointers to vectors on host */
   double *d_X, *d_Y;        /* Pointers to vectors on device */
   double *d_result;        /* Pointer to result on device */       
   double result = 0.0;
   double result_ref;

   /* Initialize CUBLAS */
   fprintf(stderr, "Running CUBLAS test of dot\n");
  
   cublasHandle_t handle;
   cublasStatus_t status;
   status = cublasCreate(&handle);
   if (status != CUBLAS_STATUS_SUCCESS) {
       fprintf(stderr, "CUBLAS initialization error\n");
       exit(EXIT_FAILURE);
   }

  /* Allocate host memory for the vectors */
  fprintf(stderr, "\nAllocating vectors on host\n");
  h_X = (double *)malloc(n * sizeof(double));
  h_Y = (double *)malloc(n * sizeof(double));

  if ((h_X == NULL) || (h_Y == NULL)) {
    fprintf(stderr, "Error allocating vectors on host\n");
    exit(EXIT_FAILURE);
  }

  /* Fill vectors with test data */
  int i;
  srand(time(NULL));
  for (i = 0; i < n; i++) {
    h_X[i] = rand() / (float)RAND_MAX;
    h_Y[i] = rand() / (float)RAND_MAX;
  }

  /* Allocate device memory for the vectors and result */
  if (cudaMalloc((void **)&d_X, n * sizeof(double)) != cudaSuccess) {
    fprintf(stderr, "Error allocating device memory\n");
    exit(EXIT_FAILURE);
  }
  
  if (cudaMalloc((void **)&d_Y, n * sizeof(double)) != cudaSuccess) {
    fprintf(stderr, "Error allocating device memory\n");
    exit(EXIT_FAILURE);
  }
  
  if (cudaMalloc((void **)&d_result, sizeof(double)) != cudaSuccess) {
    fprintf(stderr, "Error allocating device memory\n");
    exit(EXIT_FAILURE);
  }
  
  /* Initialize device vectors with the host vectors */
  status = cublasSetVector(n, sizeof(double), h_X, 1, d_X, 1);
  if (status != CUBLAS_STATUS_SUCCESS) {
    fprintf(stderr, "Error copying vector to device\n");
    exit(EXIT_FAILURE);
  }

  status = cublasSetVector(n, sizeof(double), h_Y, 1, d_Y, 1);
  if (status != CUBLAS_STATUS_SUCCESS) {
    fprintf(stderr, "Error copying vector to device\n");
    exit(EXIT_FAILURE);
  }

  status = cublasSetVector(1, sizeof(double), &result, 1, d_result, 1);
  if (status != CUBLAS_STATUS_SUCCESS) {
    fprintf(stderr, "Error copying vector to device\n");
    exit(EXIT_FAILURE);
  }

  /* Perform dot operation using reference code */
  fprintf(stderr, "\nPerforming dot operation on host\n");
  dot_gold(h_X, h_Y, &result, n);
  result_ref = result;

  /* Perform operation using cublas in double precision */
  fprintf(stderr, "\nPerforming dot operation using CUBLAS\n");
  cublasDdot(handle, n, d_X, 1, d_Y, 1, d_result);
  if (status != CUBLAS_STATUS_SUCCESS) {
    fprintf(stderr, "Kernel execution error\n");
    exit(EXIT_FAILURE);
  }

  /* Read the result back */
  status = cublasGetVector(1, sizeof(double), d_result, 1, &result, 1);
  if (status != CUBLAS_STATUS_SUCCESS) {
    fprintf(stderr, "Error copying result to host\n");
    exit(EXIT_FAILURE);
  }

  /* Check result against reference */
  double diff = fabs(result_ref - result);

  /* Free memory */
  free(h_X);
  free(h_Y);

  cudaFree(d_X);
  cudaFree(d_Y);

  /* Shut down CUBLAS */
  status = cublasDestroy(handle);
  if (status != CUBLAS_STATUS_SUCCESS) {
    fprintf(stderr, "CUBLAS shutdown error\n");
    exit(EXIT_FAILURE);
  }

  fprintf(stderr, "Diff: %f\n", diff);
  exit(EXIT_SUCCESS);
}
