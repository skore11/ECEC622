The code compiles and runs on xunil-05.
Run the commans make to compile the code via the MAkefile.